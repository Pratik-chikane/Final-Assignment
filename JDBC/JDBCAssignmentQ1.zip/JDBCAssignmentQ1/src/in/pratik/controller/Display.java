package in.pratik.controller;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import jdbc.program.util.JdbcUtil;



public class Display {
	public static void main(String[] args) throws SQLException {
		
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;

		try {
			connection = JdbcUtil.getJdbcConnection();

			String sqlSelectQuery = "select id,name,address,salary from employee";
			if (connection != null)
				pstmt = connection.prepareStatement(sqlSelectQuery);

			if (pstmt != null) {
				resultSet = pstmt.executeQuery();
			}
			
			if (resultSet != null) {

				System.out.println("EID\tENAME\tEADDRESS\tESAL");
				while (resultSet.next()) {
					
					System.out.println(resultSet.getInt(1) + "\t" + resultSet.getString(2) + "\t" + resultSet.getString(3)
							+ "\t\t" + resultSet.getInt(4) );
				} 
			}

		} catch (IOException ie) {
			ie.printStackTrace();
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.cleanUp(connection, pstmt, resultSet);
			System.out.println("Closing the resource...");

		}
	}

}

