package jdbc.program.util;

import java.io.FileInputStream;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class JdbcUtil {

	private JdbcUtil() {

	}

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static Connection getJdbcConnection() throws Exception {

		FileInputStream fis = new FileInputStream(
				"C:\\Users\\Acer\\eclipse-workspace\\JDBCApp\\application.properties");
		Properties properties = new Properties();
		properties.load(fis);

		// String url = "jdbc:mysql://localhost:3306/classdatabase";
//		String url = properties.getProperty("url");
		// String password = "root";
//		String password = properties.getProperty("password");
		// String user = "root";
//		String user= properties.getProperty("user");
//		System.out.println(url);
		Connection connection = DriverManager.getConnection(properties.getProperty("url"),
				properties.getProperty("user"), properties.getProperty("password"));
		return connection;
	}

	public static void cleanUp(Connection connection, Statement statement, ResultSet resultSet) {
		if (connection != null) {
			try {
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (statement != null) {
			try {
				statement.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
