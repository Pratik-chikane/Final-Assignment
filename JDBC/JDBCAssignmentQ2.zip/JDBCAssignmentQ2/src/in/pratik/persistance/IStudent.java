package in.pratik.persistance;

import in.pratik.model.Student;

public interface IStudent {
	public String save(Student student);
	public Student getById(Integer id);
	public Student update(Student student);
	public String deleteById(Integer id);

}
