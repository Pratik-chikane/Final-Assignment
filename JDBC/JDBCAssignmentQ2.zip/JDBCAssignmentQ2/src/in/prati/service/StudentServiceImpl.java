package in.prati.service;

import in.pratik.model.Student;
import in.pratik.persistance.IStudent;
import in.pratik.persistance.StudentImpl;
public class StudentServiceImpl implements IStudentService {
	
	
	IStudent repo=new StudentImpl();

	@Override
	public String save(Student student) {
		
		return repo.save(student);
	}

	@Override
	public Student getById(Integer id) {
		
		return repo.getById(id);
	}

	@Override
	public Student update(Student student) {
		
		return repo.update(student);
	}

	@Override
	public String deleteById(Integer id) {
	
		return repo.deleteById(id);
	}

}