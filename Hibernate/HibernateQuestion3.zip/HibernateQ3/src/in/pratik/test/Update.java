package in.pratik.test;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.pratik.model.HibernateStudent2;
import in.pratik.util.HibernateUtil;

public class Update {
	public static void main(String[] args) {
		Session session = null;
		Transaction transaction = null;
		Scanner scanner = null;
		boolean flag = false;

		try {
			scanner = new Scanner(System.in);
			System.out.println("Enter the id whose details to be updated");
			Integer id = scanner.nextInt();
			System.out.println("Enter the name");
			String name = scanner.next();
			System.out.println("Enter the address");
			String address = scanner.next();
			System.out.println("Enter the age");
			Integer age = scanner.nextInt();

			session = HibernateUtil.getSession();

			transaction = session.beginTransaction();
			if (transaction != null) {
				HibernateStudent2 student = new HibernateStudent2();
				student.setSid(id);
				student.setSname(name);
				student.setSaddress(address);
				student.setSage(age);
				session.update(student);
				flag = true;
			}

			HibernateStudent2 studentDetails = session.get(HibernateStudent2.class, id);
			System.out.println("Student saved to DB " + studentDetails);

		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}  finally {
			if (flag) {
			
				transaction.commit();
				System.out.println("Object updated to database....");
			} else {
				transaction.rollback();
				System.out.println("Object not updated to database...");
			}
			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
		}
	}

}
