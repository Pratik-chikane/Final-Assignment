package in.pratik.test;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import in.pratik.model.HibernateStudent2;
import in.pratik.util.HibernateUtil;

public class GetRecordApp {
	public static void main(String[] args) {
		Session session = null;
		Scanner scanner = null;

		try {
			scanner = new Scanner(System.in);
			System.out.println("Enter the id");
			Integer id = scanner.nextInt();
			session = HibernateUtil.getSession();

			if (session != null) {
				HibernateStudent2 student = session.get(HibernateStudent2.class, id);
				if (student != null)
					System.out.println(student);
				else
					System.out.println("Record not found for the given id :: " + id);
			}

		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();

		}
	}

}
