package in.pratik.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import in.pratik.model.HibernateStudent2;

public class HibernateUtil {
	private static SessionFactory sessionFactory = null;
	private static Session session = null;
	private HibernateUtil() {
		
	}
	static {
		 sessionFactory = new Configuration().configure().addAnnotatedClass(HibernateStudent2.class).buildSessionFactory();
	}
	
	public static Session getSession() {
		if(session == null) 
			session = sessionFactory.openSession();
		return session;
		
	}
	public static void closeSession(Session session) {
		if (session != null)
			session.close();
	}

	public static void closeSessionFactory() {
		if (sessionFactory != null)
			sessionFactory.close();
	}

}
