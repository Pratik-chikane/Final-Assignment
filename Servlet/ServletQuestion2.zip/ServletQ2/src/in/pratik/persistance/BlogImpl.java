package in.pratik.persistance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.pratik.model.Post;

public class BlogImpl implements IBlog {
	private static final String saveToDB = "insert into post(title,description,content)values(?,?,?)";
	private static final String retriveFromDB = "select * from post";

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	@Override
	public String saveBlog(Post post) {
		Connection connection = null;
		PreparedStatement statement = null;
		try {
			System.out.println(connection);
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/classdatabase", "root", "root123");
			statement = connection.prepareStatement(saveToDB);
			statement.setString(1, post.getTitle());
			statement.setString(2, post.getDescription());
			statement.setString(3, post.getContent());
			int result = statement.executeUpdate();
			if (result == 1) {
				return "Blogpost saved successfully";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return "Blog Saving failed";
	}

	@Override
	public List<Post> getAllBlogPosts() {
		Connection connection = null;
		PreparedStatement statement = null;
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/classdatabase", "root", "root123");
			statement = connection.prepareStatement(retriveFromDB);
			ResultSet resultSet = statement.executeQuery();
			List<Post> list = new ArrayList<>();
			if (list != null) {
				while (resultSet.next()) {

					Post post = new Post(resultSet.getString(2), resultSet.getString(3), resultSet.getString(4));
					list.add(post);
				}
				return list;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
				statement.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return null;
	}

}