package in.pratik.persistance;

import java.util.List;

import in.pratik.model.Post;

public interface IBlog {
	public String saveBlog(Post bp);
    public List<Post> getAllBlogPosts();
}
