package in.pratik.service;

import java.util.List;

import in.pratik.model.Post;

public interface IBlogService {
	 public String saveBlog(Post bp);
     public List<Post> getAllBlogPosts();
}