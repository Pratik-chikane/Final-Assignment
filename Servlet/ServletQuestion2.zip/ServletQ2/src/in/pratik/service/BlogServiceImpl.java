package in.pratik.service;

import java.util.List;

import in.pratik.model.Post;
import in.pratik.persistance.BlogImpl;
import in.pratik.persistance.IBlog;

public class BlogServiceImpl implements IBlogService {

	IBlog blog =new BlogImpl();
	

	@Override
	public List<Post> getAllBlogPosts() {
		// TODO Auto-generated method stub
		return blog.getAllBlogPosts();
	}

	@Override
	public String saveBlog(Post post) {
		// TODO Auto-generated method stub
		return blog.saveBlog(post);
	}

}