package in.pratik.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import in.pratik.model.Post;
import in.pratik.service.BlogServiceImpl;
import in.pratik.service.IBlogService;

@WebServlet("/blog")
public class BlogPost extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IBlogService service = new BlogServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Post> allBlogPosts = service.getAllBlogPosts();

		HttpSession session = request.getSession();
		session.setAttribute("Blogposts", allBlogPosts);
		System.out.println(allBlogPosts);
		RequestDispatcher dispatcher = request.getRequestDispatcher("./read.jsp");
		dispatcher.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String title = request.getParameter("title");
		String description = request.getParameter("description");
		String content = request.getParameter("content");
		Post post = new Post(title, description, content);
		String result = service.saveBlog(post);

		HttpSession session = request.getSession();
		session.setAttribute("result", result);
		RequestDispatcher dispatcher = request.getRequestDispatcher("./result.jsp");
		dispatcher.forward(request, response);

	}

}